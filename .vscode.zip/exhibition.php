<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Exhibitions & Trade Shows</title>
  <link rel="stylesheet" href="exhibition.css" />
</head>
<body>
  <header class="service-header">
    <h1>Exhibitions & Trade Shows</h1>
    <p>From booth design to media coverage, we make your brand stand out at events.</p>
  </header>
  <section class="service-content">
    <img src="./img/conference.jpg">
    <h2>Our VIP Event Services Include:</h2>
    <ul>
         <li>Executive-Level Venue Booking</li>
      <li>Luxury Catering and Concierge</li>
      <li>Protocol and Security Services</li>
      <li>Private AV & Presentation Setup</li>
    </section>

    </ul>
  </section>
     <section class="service-content">
     <img src="./img/conference.jpg">
     <ul>
        <li>Executive-Level Venue Booking</li>
      <li>Luxury Catering and Concierge</li>
      <li>Protocol and Security Services</li>
      <li>Private AV & Presentation Setup</li>
    </ul>
  </section>
</body>
</html>
